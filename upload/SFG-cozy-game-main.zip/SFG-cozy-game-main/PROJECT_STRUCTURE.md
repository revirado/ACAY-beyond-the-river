# PROJECT_STRUCTURE.md — Mapa del proyecto para próximas iteraciones

> **REGLA PARA EL AGENTE (léeme primero):** al retomar este proyecto, lee SOLO este archivo
> para conocer la estructura. No hagas un nuevo exploration del código salvo que necesites
> el detalle línea a línea de un archivo puntual. El historial completo de trabajo está en
> `worklog.md` (apéndice incremental) y la deuda de features en `TODO.md`.

---

## 1. Qué es

**Cozy Trading Village (PoC / vertical slice)** — juego 2D cozy de comercio estilo top-down,
renderizado en **Canvas 2D** dentro de una app **Next.js 16 (App Router) + React 19 + TypeScript 5**.
Estado del juego con **Zustand** (snapshot UI), UI React como overlays sobre el canvas.
El juego corre 100% en el cliente: **no usa base de datos, ni Prisma, ni API routes funcionales**
(limpieza Prisma completada en Task 8; `src/app/api/route.ts` es un placeholder "hello world" sin uso).

## 2. Comandos

```bash
bun run dev     # next dev -p 3000 (loguea a dev.log) — servidor de desarrollo
bun run lint    # eslint .  (debe terminar en 0 problemas)
bun run build   # next build  (simple, listo para Vercel)
bun run start   # next start  (producción local)
```

**Deploy Vercel: READY.** Build script simple (`next build`), sin `output: 'standalone'`,
sin Prisma. Única variable de entorno opcional: `DEV_MODE` (setear en el dashboard de Vercel;
en local vive en `.env`).

## 3. Mapa de archivos

```
src/
  app/
    page.tsx               # Server component: lee process.env.DEV_MODE (=== 'true') y renderiza <GameRoot devMode={...}/>
    layout.tsx             # <html lang="en"> + metadata (default EN)
    globals.css            # Tailwind 4 + tema
    api/route.ts           # Placeholder "hello world" — NO se usa; se puede borrar si molesta
  components/game/         # UI React (overlays posicionados sobre el canvas, letterbox 16:9)
    GameRoot.tsx           # Orquestador: monta/destruye el engine, escalado letterbox, overlays por pantalla
    TitleOverlay.tsx       # Título + botón Start + hints de controles + nota DEV_MODE (solo si devMode=true)
    HudOverlay.tsx         # Monedas, inventario, chip DayClock (anillo radial SVG), skyline de prosperidad
    InteractionOverlay.tsx # Ventana de diálogo estilo visual-novel: panel flotante z-20 CENTRADO EN EL VIEWPORT
                           # (left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2: el CENTRO del panel coincide con el
                           # centro del viewport en X e Y, sin importar el alto del contenido: 1 ítem ≈ 35%, 5 ítems
                           # ≈ 78%; max-h calc(100%-6rem) y la lista colapsa con shrink+overflow); contenedor único
                           # inset-0 pointer-events-none (clics fuera del panel → canvas → cierran); selección ↑/↓
                           # SIN ciclado (clamp), Enter ejecuta
    MenuOverlay.tsx        # Pausa: continuar, slider música/mute, switcher idioma EN/SPA, reiniciar
    RestartOverlay.tsx     # Confirmación de reinicio
    Toasts.tsx             # Avisos auto-dismiss (top-16, bajo el reloj)
    AssetImg.tsx           # <img> resuelta por id lógico desde el índice de assets
  game/
    core/
      types.ts             # CONTRATOS congelados (ScreenId, UiBridge, snapshots, datos de mundo)
      config.ts            # CONFIG: resolución virtual 1280x720, movementAngle 45°, day (dayLengthSec 180,
                           #   fases dawn/day/dusk/night), studio.background, volúmenes
      context.ts           # ScreenContext/UiBridge: puente screens ↔ engine
      GameEngine.ts        # Loop rAF + watchdog anti-pestaña-oculta, música por pantalla, syncUI → Zustand,
                           #   acciones UI (start/resume/restart/trade/volume/mute/locale)
      ScreenManager.ts     # Registro de pantallas, switches con/sin fade (última intención gana)
      FadeSystem.ts        # idle→toBlack→hold→fromBlack; update recibe SEGUNDOS, duraciones en ms;
                           #   hold se entra UNA vez por transición (flag heldOnce — sin él, hold re-entraba
                           #   en hold y el reinicio quedaba en negro eterno, ver §6.11)
      engineBridge.ts      # Singleton para que React invoque acciones del engine
    screens/               # Lógica de las 6 pantallas (canvas): StudioScreen (intro de estudio, solo 1ra carga),
                           #   TitleScreen, IntroScreen (2 frames, saltable), GameScreen (movimiento/interacción),
                           #   InteractionScreen (player izq / target der), MenuScreen, RestartScreen
    input/InputManager.ts  # Teclado en window (ignora e.repeat, preventDefault en flechas), clicks SOLO del
                           #   canvas convertidos a coords virtuales; onFirstGesture para desbloquear audio
    render/Renderer.ts     # Canvas 1280×720 ×dpr(máx 2); draw image/rect/text/vignette/clipRect(=overflow hidden);
                           #   anchors bottom-center/center; flip espejando; image({skewX}) = deformación PURA
                           #   (cizalla anclada en el punto de anclaje: la base no se mueve)
    render/anim.ts         # Animación por deformación (motor): ANIM_EVALUATORS (kind → lógica), evalAnim(def, t,
                           #   phaseShift) → Deform{skewX} (buffer compartido, cero allocs), phaseFromId(id) para
                           #   desincronizar instancias. pandeo = senoidal; amplitud/periodo/fase son DATOS del
                           #   índice. Extender = 1 kind (types.ts) + 1 evaluator acá. Costo 0 sin `anim`.
    assets/
      AssetLoader.ts       # loadAll() con onProgress; NUNCA rechaza; fallback automático a placeholder SVG;
                           #   getAnim(id) = AnimDef | undefined (dato del índice, disponible pre-carga)
      drawers.ts           # ~30 drawers procedurales Canvas 2D (PRNG determinista mulberry32), paleta cozy SIN azules;
                           #   grass_tuft = mata 64×48 de briznas curvas, base abajo-centro (para pandeo)
      placeholder.ts       # makePlaceholder(id) → SVG data-URI por categoría
    data/
      assetIndex.ts        # ⭐ ÍNDICE DE ASSETS: id lógico → {type: procedural|file|url|placeholder, anim?: AnimDef}.
                           #   El código NUNCA referencia rutas; reemplazar arte = editar SOLO este archivo;
                           #   animar un asset = agregarle `anim` (ej. world.grass_tuft → pandeo viento)
      world.ts items.ts trades.ts progression.ts   # Datos de economía (wheat 1c, apple 2c, bread 6c,
                           #   leña 3c, horno 12c+2 leña, pan=2 trigo+1 leña), 5 etapas de prosperidad y
                           #   WORLD_LAYOUT con 18 mats de pasto alto decorativo (grass_1..18, sin colisión)
      controlsIndex.ts     # (NO EXISTE AÚN) — propuesta pendiente de visto bueno, ver TODO.md
    logic/
      EconomySystem.ts     # executeTrade/produceBread/gatherResource (textos vía i18n keys)
      interactions.ts      # Registro genérico INTERACTION_HANDLERS (merchant/gather/oven) — sin ifs por tipo
      movement.ts CollisionSystem.ts   # Vectores caballera normalizados; AABB por ejes
    state/
      gameState.ts         # Estado lógico puro + version + subscribe
      store.ts             # Zustand: snapshot UI (GameUISnapshot incluye locale) — React NO re-renderiza por frame
    i18n/
      index.ts             # ⭐ t/tOr/setLocale/isLocale; DEFAULT_LOCALE='en' (el juego SIEMPRE arranca en inglés,
                           #   sin persistencia); AGREGAR IDIOMA = 1 JSON + 1 entrada en DICTS/LOCALES
      locales/en.json es.json   # Solo textos UI/canvas/datos (interpolación {var})
      useT.ts              # Hook reactivo al locale del store
    audio/AudioManager.ts  # WebAudio procedural (sin archivos): pad+bajo+lead, unlock en 1er gesto, mute sin chasquidos
public/                    # logo.svg, robots.txt (placeholders; arte real va por assetIndex)
TODO.md                    # Backlog de features (ver §7)
PROJECT_STRUCTURE.md       # ESTE ARCHIVO
worklog.md                 # Historial incremental de trabajo por Task ID
```

**Carpetas que NO son del juego (infra sandbox/docs, no tocar para features):**
`examples/` (demo websocket), `tests/` (scripts bash de sandbox), `upload/` (los 3 documentos
originales del brief + captura de referencia), `download/`, `skills/`.

## 4. Flujo de pantallas

```
studio (solo 1ra carga: fade in 900ms → hold 1500ms → fade out 700ms, saltable)
  → title → intro (saltable) → game ⇄ menu / restart
game → interaction (merchant/gather/oven) → vuelve a game
```

## 5. Controles actuales (hard-coded, ver TODO para el índice)

| Contexto | Teclas |
|---|---|
| Mover jugador | ↑ ↓ ← → flechas (movimiento caballera, 45°) |
| Interactuar (gameplay) | **E / Enter** (Space eliminado del gameplay) |
| Menú de pausa | ESC |
| Música on/off | M |
| Debug coords | F3 (dibuja colliders rojos + caja del jugador verde) |
| Título / Intro / Studio / Restart | Enter, Space, ESC o clic (no es interacción de gameplay) |
| Lista de opciones (interaction) | ↑/↓ mueven puntero triangular con **clamp sin ciclado**; Enter ejecuta; guard en deshabilitadas; mouse = hover+clic; clic fuera del panel cierra |

## 6. Decisiones e invariantes (NO romper)

1. **Índice de assets es el contrato central**: los IDs congelados están en `assetIndex.ts` y
   `drawers.ts` los implementa 1:1. Fallback a placeholder SVG garantizado (AssetLoader nunca rechaza).
2. **Unidades**: dt en SEGUNDOS; duraciones de fade/animación en MILISEGUNDOS.
3. **i18n solo-textos**: cero lógica en los JSON; textos de canvas usan `t()`/`tOr()` con fallback al dato original. Default: inglés.
4. **Ventana de interacción (contenedor ÚNICO, sin filas)**: los personajes (canvas) ocupan TODA la pantalla
   anclados ABAJO ("gravedad", base en `VIRTUAL_HEIGHT - 120` en `InteractionScreen`, x 160/1120 para flanquear
   el panel); el HUD (z-30) queda POR ENCIMA del panel (z-20) y no tapa del todo la base de los assets.
   El panel React mantiene su diseño y está CENTRADO EN EL VIEWPORT: `left-1/2 top-1/2 -translate-x-1/2
   -translate-y-1/2` — el centro del panel SIEMPRE es el centro del viewport (ejes X e Y); el alto varía
   con el contenido (1 ítem ≈ 35% / 5 ítems ≈ 78% del viewport, verificado) pero el centro no cambia.
   ⚠️ GEOMETRÍA DE COLLIDERS: los colliders del mundo TAMBIÉN son bottom-center (`solidToAABB`:
   rect y = obj.y − height; circle y = obj.y − 2r). El box del jugador es 44×26 con la base en p.y.
   No asumir cajas centradas — el market "llega" hasta y=390 aunque su sprite esté en y=475.
5. **DEV_MODE**: se lee SOLO en server (`page.tsx`); semántica estricta — solo el string `'true'` es true
   (`'false'`, vacío o indefinido ⇒ false). Controla únicamente la nota de arte de demostración en el título.
6. **Rendimiento**: el reloj HUD usa rAF propio con refs (0 re-renders/frame); Zustand solo publica snapshots.
7. **Clicks del juego**: solo desde el canvas; los botones React no contaminan la cola de input.
8. **Paleta cozy** (verdes/cremas/marrones/terracotas/dorados) — evitamos azules/índigo salvo pedido explícito.
9. **Footer sticky**: si algún día se agregan páginas con footer, usar `min-h-screen flex flex-col` + `mt-auto`.
10. `.env` solo contiene `DEV_MODE=true` (DATABASE_URL eliminado con Prisma). Cambiar `.env` exige reiniciar el dev server.
11. **FadeSystem — hold UNA vez por transición**: `advanceAfterCover()` entra en hold solo si `!heldOnce`
    (y `transition()` resetea el flag). `fade.long` (hold 900ms) SOLO lo usa `uiConfirmRestart()` — cualquier
    regresión del loop de hold deja el reinicio en negro eterno con el engine congelado (fade.busy=true
    impide update y nuevos switches). Verificado E2E: confirmar → fade 2.5s → intro → gameplay fresco;
    Cancelar vuelve al menú SIN resetear estado.
12. **Animación por deformación (arquitectura de motor, 3 capas separadas)**:
    (a) `Renderer.image({skewX})` = DEFORMACIÓN PURA — cizalla anclada en el punto de anclaje (base con
    bottom-center); funciona igual para procedural/SVG/file/url porque se aplica al DIBUJAR (una sola
    función, nada horneado en el asset);
    (b) `render/anim.ts` = ANIMACIÓN — evaluadores puros kind→Deform; pandeo = senoidal;
    amplitud/periodo/fase son DATOS, la función de deformación no sabe de tiempo;
    (c) `asset.anim` en el índice = PROPIEDAD declarativa para CUALQUIER asset. GameScreen la aplica
    genéricamente con `phaseFromId(obj.id)` (campo de viento por instancia). Assets sin `anim` no
    evalúan nada (costo cero). El pandeo sigue animando en menu/restart (renderizan gameplay): el
    viento no se pausa — intencional. El scatter chico horneado en drawBackground queda estático a
    propósito (capa lejana); las 18 mats de world.ts son la capa cercana animada (escala 2.6–3.2).

## 7. Trabajo pendiente (detalle en TODO.md)

- [ ] **Propuesta — índice de controles** (`src/game/data/controlsIndex.ts`, ACTION → códigos de tecla):
  PENDIENTE DE VISTO BUENO del usuario. NO implementar sin aprobación explícita.
- [ ] Limitar recolección por cantidad o tiempo (datos en world/items, no lógica).
- [ ] Diálogo estilo visual novel con respuestas predefinidas (reutilizar InteractionOverlay + INTERACTION_HANDLERS).
- [ ] Migrar textos de datos a JSON por idioma si crecen; persistencia de partida.

## 8. Gotchas de infraestructura (sandbox)

- El dev server muere si el proceso padre del shell termina → arrancar con
  `(setsid bun run dev > /dev/null 2>&1 &)`.
- **Preview de nube sin cargar = dev server muerto**: verificar con `pgrep -f next dev` +
  `curl -s -o /dev/null -w "%{http_code}" http://localhost:3000` y reiniciar. El juego en sí
  funciona (verificado por el usuario en localhost y en su deploy de Vercel).
- **E2E con teclado sintético**: agent-browser `press` es demasiado breve para mover al jugador
  (240px/s). Usar `eval` con KeyboardEvent en window + espera: keydown → wait → keyup
  (`window.dispatchEvent(new KeyboardEvent('keydown',{code:'ArrowRight',bubbles:true}))`).
  Velocidad efectiva en headless VARÍA (≈130-300px/s según watchdog): navegar por SONDEO, no por tiempo.
- **PROBE DEL ENGINE (solo dev) — usarlo SIEMPRE para E2E**: GameRoot expone `window.__game` (el engine).
  Leer `__game.state.player` (posición exacta), `__game.input.down` (teclas mantenidas),
  `__game.screens.currentId`, y `__game.screens.current?.promptObject?.id` (¡el prompt [E] activo sin
  necesidad de screenshot!). Tras cada tramo de caminata, sondear posición+prompt y ajustar.
- **Teclas trabadas (stuck keys)**: si un keyup se pierde (headless/alt-tab), la tecla queda en
  `InputManager.down` → el jugador deriva sola y queda clamped en una esquina (PARECE "congelado" pero
  se mueve cada frame). FIX: blur/visibilitychange limpian `down`. En E2E: diagnosticar con
  `__game.input.down` y resetear con `__game.input.down.clear()`.
- **Encaje contra colliders (wedge)**: si el jugador queda con su caja DENTRO de la banda Y de un collider
  pegado a su cara X (p.ej. la roca en 775,565), right/up/down quedan bloqueados a la vez; solo LEFT lo
  libera. Secuencia segura: alejarse en X → subir por encima de la banda Y del collider → rodear.
- **Fast Refresh puede recargar la página a mitad del E2E** (Turbopack + `tee dev.log` en la raíz):
  si el estado del juego se resetea a PLAYER_START o vuelve el title, fue una recarga — reintentar.
  Es un artefacto del sandbox; en localhost/Vercel no ocurre.
- **Teclas pulsadas DURANTE un fade se pierden**: `endFrame()` limpia `pressed` cada frame aunque el
  update de la pantalla esté congelado por `isTransitioning` → un Enter/Escape enviado durante
  toBlack/hold/fromBlack no llega a la pantalla destino. En E2E: sondear `__game.screens.fade.phase ===
  'idle'` antes de enviar teclas (para un humano es imperceptible: la intro es saltable cuando ya se ve).
- `tsc --noEmit` reporta errores PRE-EXISTENTES en `examples/` y `skills/` (no son del juego;
  el build los ignora vía `typescript.ignoreBuildErrors`).
- Verificación E2E histórica completa en `worklog.md` Tasks 5–9: economía, prosperidad 1→4,
  i18n, reloj, teclado, DEV_MODE, composición de interacción — todo verificado en navegador.

## 9. Regla de mantenimiento de este archivo

**Actualizar `PROJECT_STRUCTURE.md` al final de CADA tarea** que cambie estructura, layout,
contratos o conducta verificada (y sumar a §8 cualquier gotcha nuevo descubierto). Es lo que
hace que el método valga la pena: cada iteración comparte su aprendizaje con la siguiente.
