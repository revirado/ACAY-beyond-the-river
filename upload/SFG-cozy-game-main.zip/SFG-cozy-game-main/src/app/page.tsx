import { GameRoot } from '@/components/game/GameRoot'

export default function Home() {
  /**
   * DEV_MODE — variable de entorno leída SOLO en el servidor y pasada como
   * prop a la UI. Semántica solicitada:
   *   "true"  → true (se muestran los rótulos de demo, ej. nota del índice de assets)
   *   "false" → false
   *   vacío / no definida → false
   */
  const devMode = process.env.DEV_MODE === 'true'
  return <GameRoot devMode={devMode} />
}
