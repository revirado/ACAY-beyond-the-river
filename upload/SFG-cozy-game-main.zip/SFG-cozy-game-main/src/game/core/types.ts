/**
 * Tipos compartidos de todo el juego.
 * Contrato estable entre: datos, lógica, render, UI.
 */

export type ScreenId =
  | 'studio'
  | 'title'
  | 'intro'
  | 'gameplay'
  | 'interaction'
  | 'menu'
  | 'restart'

export type ItemId = 'wheat' | 'apple' | 'wood' | 'bread'

export type InteractionType = 'merchant' | 'gather' | 'oven'

/** Fase del ciclo día/noche del indicador temporal del HUD. */
export type DayPhase = 'dawn' | 'day' | 'dusk' | 'night'

export type MusicTrackId = 'title' | 'intro' | 'village' | 'menu'

/** Fuente de imagen que el renderer puede dibujar. */
export type AssetImage = HTMLImageElement | HTMLCanvasElement

export type Anchor = 'bottom-center' | 'center'

export interface Vec2 {
  x: number
  y: number
}

/** Colisión lógica, independiente del asset visual. */
export type Collider =
  | { type: 'rectangle'; width: number; height: number; offsetX?: number; offsetY?: number }
  | { type: 'circle'; radius: number; offsetX?: number; offsetY?: number }

/** Definición de un objeto del mundo (visual + lógica). */
export interface WorldObjectDef {
  id: string
  /** assetId lógico (resuelto por el AssetIndex, nunca una ruta). */
  asset: string
  /** Posición base (ancla) en coordenadas virtuales. */
  x: number
  y: number
  scale?: number
  layer?: number
  anchor?: Anchor
  collision?: Collider | null
  interaction?: {
    type: InteractionType
    label: string
    /** Para 'gather': qué recurso se recolecta. */
    resource?: ItemId
  } | null
}

/** Entrada del índice de assets: describe de dónde sale cada asset. */
export type AssetSourceType = 'file' | 'url' | 'procedural' | 'placeholder'
export interface AssetSourceDef {
  type: AssetSourceType
  /** Para 'file' (ruta pública en /public) o 'url' (https). */
  src?: string
  /** Para 'procedural': nombre del drawer incorporado. */
  drawer?: string
  /** Etiqueta para placeholders. */
  label?: string
  /** Color base para placeholders. */
  color?: string
  /**
   * Animación por deformación (feature de motor, opcional).
   * Declararla aquí anima TODAS las instancias del asset sin tocar código.
   * La lógica vive en src/game/render/anim.ts; este es solo el contrato (datos).
   */
  anim?: AnimDef
}

/* ─────────── Animación por deformación (contrato declarativo) ─────────── */

/** Tipos de animación disponibles (extensible: agregar kind + evaluator en anim.ts). */
export type AnimKind = 'pandeo'

/**
 * Definición declarativa de animación, attachable a cualquier asset vía el índice.
 * Separación de responsabilidades del motor:
 *   - Renderer.image({ skewX }) = DEFORMACIÓN PURA (una cosa: deformar, anclada en la base).
 *   - evalAnim(def, t)          = ANIMACIÓN (amplitud/frecuencia/fase → deformación por frame).
 *   - asset.anim                = PROPIEDAD (datos; cualquier asset puede llevarla).
 */
export interface AnimDef {
  kind: AnimKind
  /** Amplitud máxima de la deformación (pandeo: shear horizontal máx, ej. 0.16). */
  amplitude: number
  /** Duración del ciclo completo en segundos (velocidad de loop). */
  periodSec: number
  /** Desfasaje 0..1 dentro del ciclo (opcional; desincroniza instancias). */
  phase?: number
}

export interface CostItem {
  item: ItemId
  count: number
}

export interface FadeConfig {
  fadeIn: number
  hold: number
  fadeOut: number
}

/** Opción mostrada en la UI de interacción (comercio/recolección/producción). */
export interface UIInteractionOption {
  id: string
  kind: 'sell' | 'buy' | 'build' | 'gather' | 'produce'
  label: string
  description: string
  /** Línea de costo/ganancia, ej: "Cuesta: 3 monedas" o "Ganas: 1 moneda". */
  costLine: string
  disabled: boolean
  disabledReason: string
}

export interface UIInteractionState {
  objectId: string
  kind: InteractionType
  targetName: string
  greeting: string
  /** assetId del retrato detallado del interlocutor/objeto. */
  targetAssetId: string
  options: UIInteractionOption[]
  /** Mensaje de resultado de la última acción (o null). */
  resultMessage: string | null
}

export interface UIToast {
  id: number
  text: string
}

/** Snapshot que el engine publica hacia la UI React. */
export interface GameUISnapshot {
  ready: boolean
  screen: ScreenId
  /** Idioma activo de la UI (es | en). */
  locale: 'es' | 'en'
  coins: number
  inventory: Record<ItemId, number>
  prosperity: number
  ovenUnlocked: boolean
  interaction: UIInteractionState | null
  toasts: UIToast[]
  muted: boolean
  volume: number
  debug: boolean
  /** URLs (data URLs / rutas) de assets de UI para usar en <img>. */
  urls: Record<string, string>
}
