/** Configuración central del PoC. Parámetros de presentación ajustables sin tocar lógica. */

export const VIRTUAL_WIDTH = 1280
export const VIRTUAL_HEIGHT = 720
export const VIRTUAL_ASPECT = VIRTUAL_WIDTH / VIRTUAL_HEIGHT

export const CONFIG = {
  /** Convención de perspectiva caballera: solo transforma input → vectores. */
  movementAngle: 45,

  playerSpeed: 240,
  playerCollider: { width: 44, height: 26 },

  /** Radio de detección de interacción (distancia al punto base del objeto). */
  interactRadius: 78,

  /** Duración del ciclo de frames de caminata del sprite del mapa. */
  walkFrameMs: 160,

  /** Límites del área jugable en coordenadas virtuales. */
  worldBounds: { minX: 70, maxX: 1210, minY: 195, maxY: 612 },

  fade: {
    fast: { fadeIn: 200, hold: 0, fadeOut: 200 },
    normal: { fadeIn: 450, hold: 0, fadeOut: 450 },
    /** Usada para la transición título→intro→gameplay. */
    long: { fadeIn: 800, hold: 900, fadeOut: 800 },
  },

  intro: {
    startX: -110,
    endX: 990,
    y: 500,
    speed: 150,
    frameMs: 170,
    /** Tiempo de espera tras llegar a la puerta antes del fade. */
    arrivalDelay: 500,
  },

  /**
   * Pantalla de intro del estudio (solo en la primera carga).
   * - `background`: color sólido de fondo (editable).
   * - `logoAsset`: asset del índice usado como logo (placeholder por defecto;
   *   se reemplaza por el logo real editando SOLO el índice de assets).
   * - Envolvente temporal del logo: fade in → hold → fade out.
   */
  studio: {
    background: '#ffffff',
    logoAsset: 'ui.studio_logo',
    logoScale: 0.8,
    fadeInMs: 900,
    holdMs: 1500,
    fadeOutMs: 700,
  },

  /**
   * Ciclo día/noche del indicador temporal del HUD (datos, no lógica).
   * `dayLengthSec`: duración de un día completo en segundos reales.
   * Las fases son fracciones del ciclo: [inicio, fin) de cada una.
   */
  day: {
    dayLengthSec: 180,
    phases: [
      { id: 'dawn', from: 0.0, to: 0.15 },
      { id: 'day', from: 0.15, to: 0.6 },
      { id: 'dusk', from: 0.6, to: 0.72 },
      { id: 'night', from: 0.72, to: 1.0 },
    ],
  },

  /** Franja inferior ocupada por el HUD (React). El mundo evita dibujar gameplay ahí. */
  hudHeight: 112,

  musicVolume: 0.5,
} as const

/** Música por pantalla (el AudioManager la interpreta). */
export const MUSIC_BY_SCREEN: Record<string, string> = {
  studio: 'title',
  title: 'title',
  intro: 'intro',
  gameplay: 'village',
  interaction: 'village',
  menu: 'menu',
  restart: 'menu',
}
