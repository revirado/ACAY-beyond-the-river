import { CONFIG, MUSIC_BY_SCREEN } from '@/game/core/config'
import type { ScreenContext, UiBridge } from '@/game/core/context'
import type { GameScreen } from '@/game/core/ScreenManager'
import { ScreenManager } from '@/game/core/ScreenManager'
import { Renderer } from '@/game/render/Renderer'
import { InputManager } from '@/game/input/InputManager'
import { AudioManager } from '@/game/audio/AudioManager'
import { AssetLoader } from '@/game/assets/AssetLoader'
import { GameState } from '@/game/state/gameState'
import { useGameStore } from '@/game/state/store'
import type { MusicTrackId, UIInteractionState } from '@/game/core/types'
import { UI_ASSET_URLS } from '@/game/data/assetIndex'
import { evaluateProgression } from '@/game/data/progression'
import { setLocale, getLocale, stageMessageKey, tOr, isLocale } from '@/game/i18n'
import { TitleScreen } from '@/game/screens/TitleScreen'
import { StudioScreen } from '@/game/screens/StudioScreen'
import { IntroScreen } from '@/game/screens/IntroScreen'
import { GameScreen as GameplayScreen } from '@/game/screens/GameScreen'
import { InteractionScreen } from '@/game/screens/InteractionScreen'
import { MenuScreen } from '@/game/screens/MenuScreen'
import { RestartScreen } from '@/game/screens/RestartScreen'
import { INTERACTION_HANDLERS, findWorldObject } from '@/game/logic/interactions'

/**
 * GameEngine — dueño del game loop (requestAnimationFrame), del ScreenManager,
 * del input, del audio, del estado y de la sincronización hacia la UI React.
 * React NO participa del update por frame: solo recibe snapshots de estado.
 */
export class GameEngine implements UiBridge {
  private renderer: Renderer
  private input = new InputManager()
  private audio = new AudioManager()
  private assets = new AssetLoader()
  private state = new GameState()
  private screens = new ScreenManager()

  private canvas: HTMLCanvasElement
  private rafId = 0
  private watchdogId: ReturnType<typeof setTimeout> | null = null
  private lastFrameTime = 0
  private lastTs = 0
  private time = 0
  private running = false
  private destroyed = false

  private currentInteraction: UIInteractionState | null = null
  private debug = false
  private lastMusicScreen: string | null = null
  private lastSyncedScreen: string | null = null
  private unsubscribeState: () => void

  private ctx: ScreenContext

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas
    this.renderer = new Renderer(canvas)

    const gameplay = new GameplayScreen()
    const screens: GameScreen[] = [
      new StudioScreen(),
      new TitleScreen(),
      new IntroScreen(),
      gameplay,
      new InteractionScreen(),
      new MenuScreen(gameplay),
      new RestartScreen(gameplay),
    ]
    for (const s of screens) this.screens.register(s)

    this.ctx = {
      renderer: this.renderer,
      input: this.input,
      audio: this.audio,
      assets: this.assets,
      state: this.state,
      screens: this.screens,
      ui: this,
      toast: (text) => useGameStore.getState().pushToast(text),
      syncUI: () => this.syncUI(),
      time: 0,
      debug: false,
    }

    this.unsubscribeState = this.state.subscribe(() => this.onStateChanged())
    // Desbloqueo de audio en el primer gesto real del usuario (políticas autoplay)
    this.input.onFirstGesture(() => this.audio.unlock())
  }

  /** Carga todos los assets declarados en el índice. */
  async preload(onProgress?: (loaded: number, total: number) => void): Promise<void> {
    await this.assets.loadAll(onProgress)
    this.syncUI()
  }

  /** Arranca el loop. */
  start(): void {
    if (this.running || this.destroyed) return
    this.running = true
    this.input.attach(this.canvas)

    // Primera carga: intro del estudio → (title → intro → gameplay).
    this.screens.requestSwitch('studio', undefined, null)
    this.screens.applyPending(this.ctx)
    this.screens.fade.fadeIn(700)

    this.lastTs = performance.now()
    this.lastFrameTime = this.lastTs
    this.scheduleFrame()
  }

  destroy(): void {
    this.destroyed = true
    this.running = false
    cancelAnimationFrame(this.rafId)
    if (this.watchdogId) clearTimeout(this.watchdogId)
    this.input.detach()
    this.audio.dispose()
    this.unsubscribeState()
    useGameStore.getState().setSnapshot({ interaction: null })
  }

  /** Programa el próximo frame por rAF + watchdog anti-congelamiento. */
  private scheduleFrame(): void {
    this.rafId = requestAnimationFrame(this.loop)
    if (this.watchdogId) clearTimeout(this.watchdogId)
    this.watchdogId = setTimeout(() => {
      if (!this.running) return
      // Pestaña oculta: el navegador pausa rAF → tick manual (slow motion)
      // para que el juego no quede muerto al volver.
      if (performance.now() - this.lastFrameTime > 200) {
        this.loop(performance.now())
      } else {
        this.scheduleFrame()
      }
    }, 250)
  }

  private loop = (ts: number): void => {
    if (!this.running) return
    const dt = Math.min(0.05, Math.max(0.001, (ts - this.lastTs) / 1000))
    this.lastTs = ts
    this.time += dt

    // Teclas globales
    if (this.input.wasPressed('KeyM')) {
      this.audio.toggleMute()
      this.syncUI()
    }
    if (this.input.wasPressed('F3')) {
      this.debug = !this.debug
      this.syncUI()
    }

    // Música según pantalla actual
    const sid = this.screens.currentId
    if (sid && sid !== this.lastMusicScreen) {
      this.lastMusicScreen = sid
      this.audio.playTrack(MUSIC_BY_SCREEN[sid] as MusicTrackId)
    }
    if (sid && sid !== this.lastSyncedScreen) {
      this.lastSyncedScreen = sid
      this.syncUI()
    }

    const ctx = this.ctx
    ctx.time = this.time
    ctx.debug = this.debug

    // Update (congelado durante transiciones), luego switch pendiente, luego render
    if (!this.screens.isTransitioning) {
      this.screens.current?.update(dt, ctx)
    }
    this.screens.update(dt, ctx)
    this.screens.applyPending(ctx)
    this.screens.render(this.renderer, ctx)

    this.input.endFrame()
    this.lastFrameTime = performance.now()
    this.scheduleFrame()
  }

  /** Cambio en el estado lógico → evaluar progresión + sincronizar UI. */
  private onStateChanged(): void {
    const stage = evaluateProgression(this.state)
    if (stage) {
      useGameStore.getState().pushToast(tOr(stageMessageKey(stage.level), stage.message))
    }
    this.syncUI()
  }

  /** Publica el snapshot del juego hacia el store de UI. */
  syncUI(): void {
    const st = this.state
    const urls: Record<string, string> = {}
    for (const id of UI_ASSET_URLS) {
      try {
        urls[id] = this.assets.getUrl(id)
      } catch {
        /* asset aún no cargado */
      }
    }
    useGameStore.getState().setSnapshot({
      ready: true,
      screen: this.screens.currentId ?? 'title',
      locale: getLocale(),
      coins: st.coins,
      inventory: { ...st.inventory },
      prosperity: st.prosperity,
      ovenUnlocked: st.ovenUnlocked,
      interaction: this.currentInteraction ? { ...this.currentInteraction } : null,
      muted: this.audio.isMuted,
      volume: this.audio.getVolume(),
      debug: this.debug,
      urls,
    })
  }

  /* ─────────────── UiBridge ─────────────── */

  setInteraction(state: UIInteractionState | null): void {
    this.currentInteraction = state
    this.syncUI()
  }

  /* ─────────────── Acciones desde la UI React ─────────────── */

  /** Desde el título: intro (si no se vio) o directamente al pueblo. */
  uiStartFromTitle(): void {
    const target = this.state.introCompleted ? 'gameplay' : 'intro'
    this.screens.requestSwitch(target, undefined, CONFIG.fade.normal)
  }

  uiResume(): void {
    this.screens.requestSwitch('gameplay', undefined, null)
  }

  uiRequestRestart(): void {
    this.screens.requestSwitch('restart', undefined, null)
  }

  uiCancelRestart(): void {
    this.screens.requestSwitch('menu', undefined, null)
  }

  uiConfirmRestart(): void {
    this.currentInteraction = null
    this.setInteraction(null)
    this.state.reset()
    this.screens.requestSwitch('intro', undefined, CONFIG.fade.long)
  }

  uiCloseInteraction(): void {
    this.setInteraction(null)
    this.screens.requestSwitch('gameplay', undefined, CONFIG.fade.fast)
  }

  /** Ejecuta una opción del diálogo de interacción actual. */
  uiInteractionAction(optionId: string): void {
    if (!this.currentInteraction) return
    const objectId = this.currentInteraction.objectId
    const obj = findWorldObject(objectId)
    if (!obj?.interaction) return
    const handler = INTERACTION_HANDLERS[obj.interaction.type]
    const result = handler.execute(obj.id, optionId, this.state)
    const rebuilt = handler.build(obj.id, this.state, this.assets)
    this.setInteraction({ ...rebuilt, resultMessage: result.message })
  }

  uiSetVolume(v: number): void {
    this.audio.setVolume(v)
    this.syncUI()
  }

  uiToggleMute(): void {
    this.audio.toggleMute()
    this.syncUI()
  }

  /** Cambia el idioma de la UI (es | en) y re-publica el snapshot. */
  uiSetLocale(locale: unknown): void {
    if (!isLocale(locale)) return
    setLocale(locale)
    this.syncUI()
  }

  /**
   * Estado del reloj del HUD (indicador temporal).
   * El overlay React lo lee por rAF propio para no re-renderizar por frame.
   */
  getClock(): { time: number; dayLengthSec: number } {
    return { time: this.time, dayLengthSec: CONFIG.day.dayLengthSec }
  }
}
