import type { Renderer } from '@/game/render/Renderer'
import type { InputManager } from '@/game/input/InputManager'
import type { AudioManager } from '@/game/audio/AudioManager'
import type { AssetLoader } from '@/game/assets/AssetLoader'
import type { GameState } from '@/game/state/gameState'
import type { ScreenManager } from '@/game/core/ScreenManager'
import type { UIInteractionState } from '@/game/core/types'

/** Puente hacia la UI React (implementado por el GameEngine). */
export interface UiBridge {
  setInteraction: (state: UIInteractionState | null) => void
}

/** Contexto entregado a cada pantalla del juego. */
export interface ScreenContext {
  renderer: Renderer
  input: InputManager
  audio: AudioManager
  assets: AssetLoader
  state: GameState
  screens: ScreenManager
  ui: UiBridge
  toast: (text: string) => void
  syncUI: () => void
  /** Segundos transcurridos desde el inicio del engine. */
  time: number
  debug: boolean
}
