import { useGameStore } from '@/game/state/store'
import type { GameEngine } from '@/game/core/GameEngine'

/**
 * Bridge React → Engine. El engine vive fuera del ciclo de vida de React
 * (se crea en useEffect de GameRoot); los overlays obtienen la instancia
 * por aquí para invocar acciones de UI.
 */
let instance: GameEngine | null = null

export function setEngineInstance(engine: GameEngine | null): void {
  instance = engine
}

export function getEngine(): GameEngine | null {
  return instance
}
