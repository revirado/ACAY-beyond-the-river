import es from './locales/es.json'
import en from './locales/en.json'

/**
 * ═══════════════════════════════════════════════════════════════════
 *  i18n — internacionalización mínima basada en diccionarios JSON.
 * ═══════════════════════════════════════════════════════════════════
 *
 * - Los textos de UI viven en `locales/<idioma>.json` (claves de puntos).
 * - AGREGAR UN IDIOMA NUEVO = agregar un archivo JSON + una entrada en
 *   `DICTS` y en `Locale`. Cero cambios en el código de juego.
 * - Solo se traducen TEXTOS: la lógica y el layout quedan intactos.
 * - Interpolación simple: t('econ.missingCoins', { n: 3 }) → "Te faltan 3 monedas".
 * - `tOr(key, fallback, vars)` permite usar textos de datos (world/trades)
 *   como fallback si el diccionario aún no tiene la clave.
 */

export type Locale = 'es' | 'en'

/** Idiomas disponibles (orden = orden de presentación en la UI). */
export const LOCALES: ReadonlyArray<{ id: Locale; label: string }> = [
  { id: 'en', label: 'English' },
  { id: 'es', label: 'Español' },
]

/** El juego SIEMPRE arranca en inglés (el jugador puede cambiarlo en el menú). */
export const DEFAULT_LOCALE: Locale = 'en'

type Dict = Record<string, unknown>
const DICTS: Record<Locale, Dict> = { es, en }

let current: Locale = DEFAULT_LOCALE

export function getLocale(): Locale {
  return current
}

export function setLocale(locale: Locale): void {
  if (locale in DICTS) current = locale
}

/** Type guard para valores externos (store / querystring / storage). */
export function isLocale(value: unknown): value is Locale {
  return value === 'es' || value === 'en'
}

/** Busca una clave de puntos en el diccionario. Devuelve undefined si no existe. */
function resolve(dict: Dict, key: string): string | undefined {
  let node: unknown = dict
  for (const part of key.split('.')) {
    if (node && typeof node === 'object' && part in (node as Dict)) {
      node = (node as Dict)[part]
    } else {
      return undefined
    }
  }
  return typeof node === 'string' ? node : undefined
}

/** Interpola {vars} sobre un texto ya resuelto. */
function interpolate(raw: string, vars?: Record<string, string | number>): string {
  if (!vars) return raw
  let out = raw
  for (const [k, v] of Object.entries(vars)) out = out.split(`{${k}}`).join(String(v))
  return out
}

/**
 * Traduce `key` en el idioma actual. Si la clave no existe en el idioma
 * actual cae al idioma por defecto y, como último recurso, a la propia key.
 */
export function t(key: string, vars?: Record<string, string | number>): string {
  const raw = resolve(DICTS[current], key) ?? resolve(DICTS[DEFAULT_LOCALE], key) ?? key
  return interpolate(raw, vars)
}

/**
 * Como `t`, pero con fallback explícito (útil para textos que viven en
 * archivos de datos como world.ts / trades.ts).
 */
export function tOr(
  key: string,
  fallback: string,
  vars?: Record<string, string | number>,
): string {
  const raw =
    resolve(DICTS[current], key) ??
    resolve(DICTS[DEFAULT_LOCALE], key) ??
    fallback
  return interpolate(raw, vars)
}

/** Clave del nombre de una etapa de prosperidad (usada por HUD y toasts). */
export function stageNameKey(level: number): string {
  return `progression.stage${level}.name`
}

/** Clave del mensaje de una etapa de prosperidad (usada por los toasts). */
export function stageMessageKey(level: number): string {
  return `progression.stage${level}.message`
}

/** Nombre localizado de un ítem, ya en minúsculas para frases naturales. */
export function itemNameLower(itemId: string): string {
  return t(`items.${itemId}`).toLowerCase()
}
