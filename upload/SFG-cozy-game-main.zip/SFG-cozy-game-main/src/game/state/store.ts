import { create } from 'zustand'
import type { GameUISnapshot } from '@/game/core/types'

let toastSeq = 1

interface GameStore extends GameUISnapshot {
  setSnapshot: (partial: Partial<GameUISnapshot>) => void
  pushToast: (text: string) => void
  removeToast: (id: number) => void
}

/**
 * Store de UI (Zustand) — el engine publica snapshots aquí.
 * NO es la fuente de verdad del juego: solo refleja GameState para React.
 */
export const useGameStore = create<GameStore>((set) => ({
  ready: false,
  screen: 'title',
  locale: 'en', // el juego siempre inicia en inglés (DEFAULT_LOCALE)
  coins: 0,
  inventory: { wheat: 0, apple: 0, wood: 0, bread: 0 },
  prosperity: 0,
  ovenUnlocked: false,
  interaction: null,
  toasts: [],
  muted: false,
  volume: 0.5,
  debug: false,
  urls: {},

  setSnapshot: (partial) => set(partial),

  pushToast: (text) =>
    set((s) => ({ toasts: [...s.toasts.slice(-3), { id: toastSeq++, text }] })),

  removeToast: (id) => set((s) => ({ toasts: s.toasts.filter((t) => t.id !== id) })),
}))
