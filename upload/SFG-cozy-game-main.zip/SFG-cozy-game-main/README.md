
# Something Far Greater

  

**Developed by Ariel Lamas & Gastón Lamas**

  

## Description

  

"Something Far Greater" is an immersive adventure game that invites players to explore a charming world filled with engaging interactions, resource management, and captivating storytelling. Players will navigate through various screens, each offering unique challenges and experiences, from the title screen to the gameplay and interaction screens. The game emphasizes player choice and strategy, allowing for a rich and dynamic gameplay experience.
  
  
  

> A small ant arrives in a place where everything seems enormous. It
> travels on the back of a tiny, armored creature, following paths that
> connect small communities. At first, it carries nothing. It learns
> that what one possesses may hold value for someone else, that choosing
> to keep something is also a decision, that transforming items can
> multiply their worth, and that a modest gain can return home as
> something far greater. Each journey changes the traveler, but it also
> transforms the place they call home.

  
  

## Getting Started

  

Follow these instructions to set up and run the project on your local machine.

  

### Prerequisites

  

- Node.js (version 14 or higher)

- npm (Node package manager)

  

### Installation

  

1. Clone the repository:

  

```bash

git clone https://github.com/revirado/SFG-cozy-game.git

```

  

2. Navigate to the project directory:

  

```bash

cd SFG-cozy-game

```

  

3. Install the required dependencies:

  

```bash

npm install

```

  

### Running the Project

  

To start the game, run the following command:

  

```bash

npm  start

```

  

This will launch the game in your default web browser. Enjoy your adventure in SFG!

  

## Contributing

  

If you would like to contribute to the project, please fork the repository and submit a pull request. We welcome any suggestions or improvements!

  

## License

  

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.